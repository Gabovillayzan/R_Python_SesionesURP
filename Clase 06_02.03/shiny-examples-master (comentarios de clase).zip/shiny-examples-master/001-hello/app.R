library(shiny)
library(markdown) ##prueba adicional
library(leaflet) ##Prueba 

#R MarkDown, permite empaquetar un 
#RLeafLet  permite mostrar en HTML los graficos R

# Define UI for app that draws a histogram ----
ui <- fluidPage(

  # App title ----
  titlePanel("Hola Gabriel!"),

  # Sidebar layout with input and output definitions ----
  sidebarLayout(

    # Sidebar panel for inputs ----
    sidebarPanel(

      # Input: Slider for the number of bins ----
      sliderInput(inputId = "barras",
                  label = "numero de contenedores:",
                  min = 10,
                  max = 150,
                  value = 75)

    ),

    # Main panel for displaying outputs ----
    mainPanel(

      # Output: Histogram ----
      plotOutput(outputId = "pantalla")

    )
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {

  # Histogram of the Old Faithful Geyser Data ----
  # with requested number of bins
  # This expression that generates a histogram is wrapped in a call
  # to renderPlot to indicate that:
  #
  # 1. It is "reactive" and therefore should be automatically
  #    re-executed when inputs (input$barras) change
  # 2. Its output type is a plot
  output$pantalla <- renderPlot({

    x    <- faithful$waiting
    barras <- seq(min(x), max(x), length.out = input$barras + 1)

    hist(x, breaks = barras, col = "#EE4000", border = "#0A000F",
         xlab = "tiempo de espera (minutos)",
         main = "Histograma")

    })

}

# Create Shiny app ----
shinyApp(ui = ui, server = server)
