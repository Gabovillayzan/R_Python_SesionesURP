This app demonstrates two ways of selecting points.

The first way is to use `nearPoints()` with the click input object.

The second way is to use `brushedPoints()` with the brush input object.
