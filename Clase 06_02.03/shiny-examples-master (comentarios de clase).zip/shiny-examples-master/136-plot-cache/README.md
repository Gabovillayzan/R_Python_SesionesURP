This app demonstrates basic plot caching.
