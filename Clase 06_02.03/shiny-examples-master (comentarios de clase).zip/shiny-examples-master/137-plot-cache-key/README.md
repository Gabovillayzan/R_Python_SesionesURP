This app demonstrates using multiple items in the plot cache key.
